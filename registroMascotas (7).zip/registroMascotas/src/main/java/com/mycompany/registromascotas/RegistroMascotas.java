/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registromascotas;

import vistas.VentanaPrincipal;

/**
 *
 * @author Kevin
 */
public class RegistroMascotas {

    public static void main(String[] args) {
 
            new VentanaPrincipal().setVisible(true);
    }
    }


   

